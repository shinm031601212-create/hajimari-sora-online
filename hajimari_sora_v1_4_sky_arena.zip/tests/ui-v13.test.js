"use strict";
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const read=(p)=>fs.readFileSync(path.join(__dirname,'..',p),'utf8');
test('v1.3 same cards, rules and engine',()=>{
 assert.equal(JSON.parse(read('public/cards.json')).length,18);
 const E=require('../engine');assert.equal(typeof E.computeBattle,'function');
});
test('v1.3 victory tears exactly the losing side and ties tear both',()=>{
 const on=read('public/online.js'),off=read('public/offline.html');
 for(const s of [on,off]){
  assert.match(s,/winner==='tie'\?\[0,1\]/);
  assert.match(s,/skyFracture\(/);
  assert.match(s,/sky-break-label/);
  assert.match(s,/sky-shard/);
 }
 assert.match(on,/g\.last\.winner===seat\?1:0/);
 assert.match(off,/S\.last\.winner===0\?1:0/);
});
test('v1.3 has no sound or AudioContext, reduced-motion fallback',()=>{
 for(const p of ['public/online.js','public/offline.html']){
  const s=read(p);
  for(const banned of ['AudioContext','soundCue','skySoundButton','skySound=','data-action="sound"']) assert.equal(s.includes(banned),false,`${p}: ${banned}`);
 }
 for(const p of ['public/online.css','public/offline.html'])assert.match(read(p),/prefers-reduced-motion:reduce/);
});
test('original visual cards remain until existing cost transition',()=>{
 for(const p of ['public/online.js','public/offline.html']){
  const s=read(p);assert.match(s,/wrap.appendChild\(card\)/);assert.match(s,/コスト支払いが終わるまで場に残ります/);
 }
});
