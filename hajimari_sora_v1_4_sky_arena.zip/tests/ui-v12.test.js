'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
function read(p){return fs.readFileSync(path.join(root,p),'utf8');}
test('v1.2 controls exist in online and offline layouts',()=>{
 for(const p of ['public/index.html','public/offline.html']){
  const s=read(p);
  assert.match(s,/id="skyQuickBar"/);
  assert.match(s,/id="skyQuickButton"/);
  assert.match(s,/id="battleScreen"|id="gameScreen"/);
 }
 assert.match(read('public/online.js'),/updateQuickAction\(\)/);
 assert.match(read('public/offline.html'),/updateSkyQuick\(\)/);
});
test('v1.2 keeps 18 cards and existing game engine unchanged',()=>{
 const cards=JSON.parse(read('public/cards.json'));
 assert.equal(cards.length,18);
 for(const c of cards) assert.ok(fs.statSync(path.join(root,'public',c.art.replace(/^\//,''))).size>1000);
 const E=require('../engine.js');
 assert.equal(typeof E.computeBattle,'function');
});
