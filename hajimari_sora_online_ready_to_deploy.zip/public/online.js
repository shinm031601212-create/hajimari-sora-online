'use strict';
let cards=[],byId={},socket=null,roomData=null,seat=null,roomId=null,authToken=null;
let deck={cloud:2,sun:2,star:1,rock:2,bird:2,flower:2,pillar:1,book:1,sword:1,wind:1};
const STARTER={...deck};
const RUSH={rock:2,flower:2,sword:2,wind:2,star:1,storm:1,pillar:1,tree:1,skull:1,three:1,sun:1};
const TRICK={cloud:2,sun:2,star:2,bird:1,moon:1,tree:1,book:1,leaf:1,kama:1,horn:1,flower:1,skull:1};
let selectedCard=null,ready=false,storedSession=null,lastRerenderAt=0;
const $=id=>document.getElementById(id);
const htmlEscape=str=>String(str??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notify(msg){$('toast').textContent=msg;$('toast').classList.remove('hidden');clearTimeout(notify._tid);notify._tid=setTimeout(()=>$('toast').classList.add('hidden'),4000);}
function total(d){return Object.values(d).reduce((s,n)=>s+(Number(n)||0),0);}
function valid(d){return total(d)===15&&cards.every(c=>Number.isInteger(d[c.id]||0)&&(d[c.id]||0)>=0&&(d[c.id]||0)<=2);}
function deckList(){return cards.flatMap(c=>Array(deck[c.id]||0).fill(c.id));}
function saveDeck(){try{localStorage.setItem('skyDeck',JSON.stringify(deck));}catch{}}
function sessionSave(){try{sessionStorage.setItem('skyRoom',JSON.stringify({room:roomId,token:authToken}));}catch{}}
function sessionClear(){try{sessionStorage.removeItem('skyRoom');}catch{}}
function readSession(){try{return JSON.parse(sessionStorage.getItem('skyRoom'));}catch{return null;}}
function send(o){if(socket?.readyState!==WebSocket.OPEN){notify('通信が切れています。再接続を待ってください。');return false;}socket.send(JSON.stringify(o));return true;}
function connect(){
 const protocol=location.protocol==='https:'?'wss:':'ws:';
 socket=new WebSocket(`${protocol}//${location.host}/ws`);
 $('connection').textContent='サーバーへ接続しています…';
 socket.onopen=()=>{
  $('connection').textContent='● オンライン接続中';$('connection').className='connection ok';
  const old=readSession();const invited=new URLSearchParams(location.search).get('room');if(old?.room&&old?.token&&(!invited||invited.toUpperCase()===old.room))send({type:'join',room:old.room,token:old.token});
 };
 socket.onmessage=e=>{let m;try{m=JSON.parse(e.data);}catch{return;}
  if(m.type==='error'){
   notify(m.message);
   if(m.message?.includes('ルームが見つかりません')||m.message?.includes('満員')){sessionClear();if(!roomId){$('onlineStart').classList.remove('hidden');}}
  }
  if(m.type==='left'){roomData=null;roomId=null;sessionClear();render();}
  if(m.type==='joined'){roomId=m.room;authToken=m.token;seat=m.seat;selectedCard=null;sessionSave();history.replaceState(null,'',`/?room=${roomId}`);}
  if(m.type==='room'){roomData=m;seat=m.seat;roomId=m.room;ready=!!m.players?.[seat]?.ready;render();}
 };
 socket.onclose=()=>{
  $('connection').textContent='● 接続が切れました。再接続中…';$('connection').className='connection off';
  setTimeout(connect,1800);
 };
 socket.onerror=()=>{};
}
function setRoomUrl(code){if(code){$('roomCode').value=code.toUpperCase();}}
function startJoin(){const id=$('roomCode').value.toUpperCase().replace(/\s/g,'');if(id.length!==6){notify('招待コードは6文字です');return;}send({type:'join',room:id,name:$('myName').value});}
function copyInvite(){const link=`${location.origin}/?room=${roomId}`;
 if(navigator.clipboard?.writeText)navigator.clipboard.writeText(link).then(()=>notify('招待URLをコピーしました')).catch(()=>prompt('このURLをコピーしてください',link));
 else prompt('このURLをコピーしてください',link);
}
function poolHtml(){return cards.map(c=>{
 const n=deck[c.id]||0;
 return `<div class="pool-card"><button class="pool-image" data-action="zoom" data-id="${c.id}" aria-label="${htmlEscape(c.name)}を拡大"><img src="${c.art}" loading="lazy" alt="${htmlEscape(c.name)}"></button><div style="min-width:0;flex:1"><div class="pool-name">${htmlEscape(c.name)}</div><div class="pool-meta">コスト${c.cost} ／ 魂値${c.soul}</div><div class="pool-desc">${c.ability?'【'+htmlEscape(c.ability)+'】'+htmlEscape(c.effect):'特殊能力なし'}</div><div class="qty"><button data-action="minus" data-id="${c.id}" ${!n||ready?'disabled':''}>−</button><b>${n}</b><button data-action="plus" data-id="${c.id}" ${n>=2||total(deck)>=15||ready?'disabled':''}>＋</button></div></div></div>`;
 }).join('');}
function makePool(){const cnt=total(deck);$('count').textContent=`${cnt} / 15`;$('count').classList.toggle('bad',cnt!==15);$('deckPool').innerHTML=poolHtml();$('readyBtn').disabled=ready||!valid(deck);$('readyBtn').classList.toggle('hidden',ready);$('unreadyBtn').classList.toggle('hidden',!ready);$('readyStatus').textContent=ready?'準備完了。相手を待っています':'自分のデッキを選んでください';}
function renderRoom(){const p=roomData.players;
 $('codeView').textContent=roomId;
 $('seatStatus').innerHTML=[0,1].map(i=>{
  const item=p?.[i];return `<div class="room-seat ${item?.ready?'is-ready':''} ${!item?'waiting':''}"><div class="small">${i===0?'プレイヤー1':'プレイヤー2'}${i===seat?'（あなた）':''}</div><b>${item?htmlEscape(item.name):'参加者を待っています'}</b><small>${item?(item.ready?'✓ 準備完了':'デッキ作成中')+' ／ '+(item.connected?'オンライン':'接続待ち'):'招待URLを送ってください'}</small></div>`;
 }).join('');
 makePool();
}
function sideStat(s,name){return `<h3>${htmlEscape(name)}</h3><div class="mini-stats"><span>🃏 山札 ${s.deck}</span><span>✋ 手札 ${s.handCount}</span><span>♻ トラッシュ ${s.trash}</span><span>↺ リフレッシュ ${s.refreshed}</span></div><div class="shields">${Array.from({length:3},(_,i)=>`<div class="shield ${i<s.barriers?'':'empty'}">${i<s.barriers?'✦':'×'}</div>`).join('')}</div>`;}
function fieldCard(side,label){
 let card=side.battle;
 return `<h3>${htmlEscape(label)}</h3>${side.back?'<div class="backcard"><b>✦</b><span>はじまりの空の町</span><span>裏向き</span></div>':card?`<img class="game-card" data-action="zoom" data-id="${card.type}" src="${byId[card.type].art}" alt="${htmlEscape(byId[card.type].name)}">`:'<div class="no-card">カードなし</div>'}`;
}
function resultHtml(g){if(!g.last)return'';
 const r=g.last;
 const myFinal=r.final[seat],opFinal=r.final[1-seat];
 const meWin=r.winner==='tie'?'引き分け':r.winner===seat?'あなたの勝ち！':'相手の勝ち';
 return `<div class="result ${r.winner==='tie'?'tie':r.winner===seat?'win':'lose'}"><b>${myFinal} 対 ${opFinal}：${meWin}</b><small>最初の比較 ${r.baseline[seat]} 対 ${r.baseline[1-seat]}</small>${r.events.length?`<small>${r.events.map(htmlEscape).join(' ／ ')}</small>`:''}</div>`;
}
function wait(text){return `<div class="wait-mark">${htmlEscape(text)}</div>`;}
function button(text,action='ack',style=''){return `<div class="actions"><button class="btn ${style}" data-action="${action}">${text} →</button></div>`;}
function actionHtml(g){
 const mine=g.me,enemy=g.op,p=roomData.players;
 if(g.phase==='choose'){
  if(mine.selected)return `<h2>相手のカード選択を待っています</h2>${wait(enemy.selected?'両者の選択完了を処理しています':'相手がカードを選んでいます…')}`;
  const hand=`<div class="hand">${g.hand.map(c=>{const t=byId[c.type];return `<button class="choice-card hand-card ${selectedCard?.uid===c.uid?'selected':''}" data-action="select" data-uid="${htmlEscape(c.uid)}"><img src="${t.art}" alt="${htmlEscape(t.name)}"><strong>${htmlEscape(t.name)}　コスト${t.cost}・魂値${t.soul}</strong><p>${t.ability?`【${htmlEscape(t.ability)}】${htmlEscape(t.effect)}`:'特殊能力なし'}</p><em>${selectedCard?.uid===c.uid?'✓ 選択中':'タップして選択'}</em></button>`;}).join('')}</div>`;
  const keep=mine.battle?`<button class="keep ${selectedCard?.kind==='keep'?'selected':''}" data-action="keep">${selectedCard?.kind==='keep'?'✓ ':''}《${htmlEscape(byId[mine.battle.type].name)}》を表向きで続投する（コスト${byId[mine.battle.type].cost}）</button>`:'';
  return `<h2>カード選択フェイズ</h2><p class="small">${enemy.selected?'相手は選択済み。':'お互いカードを選んでいるところです。'}手札のカードを選ぶか、勝ち残ったカードを続投してください。</p>${keep}${hand}${button('選んだカードを確定','lock')}`;
 }
 if(g.phase==='optional')return g.optionalMine?`<h2>✨ 特殊能力で1枚引ける！</h2><p>引けば手札が増えますが、リフレッシュが早くなるかもしれません。</p><div class="actions"><button class="btn" data-action="drawYes">1枚引く</button><button class="btn secondary" data-action="drawNo">引かない</button></div>`:`<h2>特殊能力を処理しています</h2>${wait('相手がカードを引くか選んでいます…')}`;
 if(g.phase==='over'){
  const result=g.winner==='tie'?'🤝 引き分け':g.winner===seat?'🏆 あなたの勝利！':'相手の勝利';
  return `<div class="outcome-card"><h2>${result}</h2><p>${htmlEscape(g.reason)}</p><p>対戦ターン数：${g.round}</p>${roomData.rematch[seat]?wait('相手の再戦希望を待っています'):`${button('もう一度対戦する','rematch','gold')}`}</div>`;
 }
 const steps={open:['👁 オープンフェイズ','両者のカード選択が確定しました。お互いのカードを公開します。','カードを公開する'],battle:['⚔ バトルフェイズ','魂値を比較し、発動条件を満たす特殊能力を処理します。','勝負する'],result:['✨ バトル結果','最終的な勝敗が確定しました。次はコストの支払いです。','結果を確認して進む'],payment:['💠 コストフェイズ','勝った人も負けた人もコストを支払います。','コストを支払う'],cost:['💠 コストの確認','デッキから出したカードを確認し、トラッシュに置きます。','コストを確認して進む'],end:['✅ 終了フェイズ','負けたカードはトラッシュへ、勝ったカードはそのまま残ります。','次のターンへ']};
 const st=steps[g.phase];if(!st)return wait('通信を待っています');
 let extra='';if(g.phase==='cost')extra=`<div class="costgrid">${[[g.me,'あなた'],[g.op,'相手']].map(([s,n])=>`<div class="costbox"><strong>${n}のコスト：${s.costZone.length}枚</strong><div class="costpieces">${s.costZone.map(id=>`<img src="${byId[id].art}" alt="${htmlEscape(byId[id].name)}" title="${htmlEscape(byId[id].name)}">`).join('')||'なし'}</div></div>`).join('')}</div>`;
 return `<h2>${st[0]}</h2><p>${st[1]}</p>${extra}${g.ack?wait('あなたは確認済み。相手の操作を待っています。'):button(st[2])}`;
}
function renderBattle(){const g=roomData.game;if(!g)return;
 const left=roomData.players?.[seat]?.name||'あなた',right=roomData.players?.[1-seat]?.name||'相手';
 const n={choose:'カード選択',open:'オープン',battle:'バトル',result:'バトル結果',optional:'特殊能力',payment:'コスト',cost:'コスト確認',end:'終了',over:'ゲーム終了'};
 $('phasePanel').innerHTML=`<div class="phase-info"><span class="tag">第${g.round}ターン</span><b>${n[g.phase]||g.phase}</b><span class="small">オンライン対戦 ／ 部屋 ${roomId}</span></div><div class="small">${htmlEscape(left)} VS ${htmlEscape(right)}</div>${roomData.players?.[1-seat]?.connected?'':'<div class="warn">相手の接続が切れています。再接続を待っています。</div>'}`;
 $('ownStat').innerHTML=sideStat(g.me,`${left}（あなた）`);$('enemyStat').innerHTML=sideStat(g.op,right);
 $('ownBattle').innerHTML=fieldCard(g.me,'あなたのカード');$('enemyBattle').innerHTML=fieldCard(g.op,'相手のカード');
 $('battleResult').innerHTML=resultHtml(g);
 $('gameControls').innerHTML=actionHtml(g);
 $('battleLogs').innerHTML=g.logs.slice(-20).reverse().map(x=>`<div class="logline">${htmlEscape(x)}</div>`).join('');
}
function render(){
 const inRoom=!!roomData,inGame=!!roomData?.game;
 $('onlineStart').classList.toggle('hidden',inRoom);
 $('roomScreen').classList.toggle('hidden',!inRoom||inGame);
 $('battleScreen').classList.toggle('hidden',!inGame);
 if(inRoom&&!inGame)renderRoom();
 if(inGame)renderBattle();
}
function openZoom(id){const c=byId[id];if(!c)return;$('modalBody').innerHTML=`<h3>${htmlEscape(c.name)}　コスト${c.cost} ／ 魂値${c.soul}</h3><img src="${c.art}" alt="${htmlEscape(c.name)}" style="width:100%;max-width:410px;display:block;margin:8px auto;border-radius:10px"><p><b>${c.ability?'【'+htmlEscape(c.ability)+'】':'特殊能力なし'}</b> ${htmlEscape(c.effect)}</p><p class="small">${htmlEscape(c.flavor)}</p>`;$('cardModal').classList.remove('hidden');}
function setPreset(type){if(ready)return;
 if(type==='starter')deck={...STARTER};else if(type==='rush')deck={...RUSH};else if(type==='trick')deck={...TRICK};else if(type==='random'){const ids=cards.map(c=>c.id);deck={};while(total(deck)<15){const id=ids[Math.floor(Math.random()*ids.length)];if((deck[id]||0)<2)deck[id]=(deck[id]||0)+1;}}
 saveDeck();makePool();}
function initHandlers(){
 $('scrollOnline').onclick=()=>$('onlineStart').scrollIntoView({behavior:'smooth'});
 $('createRoom').onclick=()=>send({type:'create',name:$('myName').value});
 $('joinRoom').onclick=startJoin;$('copyInvite').onclick=copyInvite;
 $('readyBtn').onclick=()=>{if(!valid(deck))return notify('15枚にしてから準備してください');send({type:'ready',deck:deckList()});};
 $('unreadyBtn').onclick=()=>send({type:'ready',ready:false});
 $('closeCard').onclick=()=>$('cardModal').classList.add('hidden');
 $('cardModal').addEventListener('click',e=>{if(e.target.id==='cardModal')$('cardModal').classList.add('hidden')});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')$('cardModal').classList.add('hidden')});
 document.addEventListener('click',e=>{
  const btn=e.target.closest('button[data-action],button[data-preset],img[data-action]');if(!btn||btn.disabled)return;
  if(btn.dataset.preset){setPreset(btn.dataset.preset);return;}
  const a=btn.dataset.action,id=btn.dataset.id,g=roomData?.game;
  if(a==='plus'||a==='minus'){
   if(ready)return;
   const n=(deck[id]||0)+(a==='plus'?1:-1);if(n<0||n>2||(a==='plus'&&total(deck)>=15))return;deck[id]=n;saveDeck();makePool();
  }
  if(a==='zoom')openZoom(id);
  if(a==='select'){selectedCard={kind:'play',uid:btn.dataset.uid};renderBattle();}
  if(a==='keep'){selectedCard={kind:'keep'};renderBattle();}
  if(a==='lock'){
   if(!selectedCard)return notify('カードを選んでください');
   send({type:'pick',choice:selectedCard});selectedCard=null;
  }
  if(a==='ack')send({type:'ack'});
  if(a==='drawYes'||a==='drawNo')send({type:'optional',yes:a==='drawYes'});
  if(a==='rematch')send({type:'rematch'});
 });
}
async function init(){
 const response=await fetch('/cards.json');cards=await response.json();byId=Object.fromEntries(cards.map(c=>[c.id,c]));
 try{let d=JSON.parse(localStorage.getItem('skyDeck'));if(d&&valid(d))deck=d;}catch{}
 const invite=new URLSearchParams(location.search).get('room');if(invite){setRoomUrl(invite);const old=readSession();if(old?.room&&old.room!==invite.toUpperCase())sessionClear();}
 initHandlers();makePool();connect();
}
setInterval(()=>{if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify({type:'heartbeat'}));},45000);
init().catch(e=>{$('connection').textContent='ゲームデータの読み込みに失敗しました';console.error(e);});
