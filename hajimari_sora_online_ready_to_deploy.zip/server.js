'use strict';
const http=require('node:http');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const E=require('./engine.js');
const ROOT=path.join(__dirname,'public');
const PORT=process.env.PORT!==undefined?Number(process.env.PORT):3000;
const rooms=new Map();
const CODE_CHARS='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.ico':'image/x-icon'};
const server=http.createServer((req,res)=>{
 if(req.method!=='GET'){res.writeHead(405).end('Method Not Allowed');return;}
 const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);
 if(url.pathname==='/health'){res.writeHead(200,{'content-type':'application/json; charset=utf-8'}).end(JSON.stringify({ok:true,rooms:rooms.size}));return;}
 let p=url.pathname==='/'?'/index.html':url.pathname;
 if(p.includes('..')||p.includes('\\')||p.includes('\0')){res.writeHead(403).end();return;}
 try{p=decodeURIComponent(p);}catch{res.writeHead(400).end();return;}
 const target=path.resolve(ROOT,'.'+p);
 if(!target.startsWith(ROOT+path.sep)){res.writeHead(403).end();return;}
 fs.stat(target,(err,stat)=>{
  if(err||!stat.isFile()){res.writeHead(404).end('Not Found');return;}
  res.setHeader('content-type',types[path.extname(target)]||'application/octet-stream');
  res.setHeader('x-content-type-options','nosniff');
  res.setHeader('referrer-policy','same-origin');
  res.setHeader('cache-control',p==='/index.html'||p==='/offline.html'?'no-store':'public, max-age=86400');
  fs.createReadStream(target).on('error',()=>{if(!res.headersSent)res.writeHead(500);res.end();}).pipe(res);
 });
});
const GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function frame(data,opcode=1){const msg=Buffer.isBuffer(data)?data:Buffer.from(String(data));const size=msg.length;let header;
 if(size<126){header=Buffer.alloc(2);header[1]=size;}
 else if(size<=65535){header=Buffer.alloc(4);header[1]=126;header.writeUInt16BE(size,2);}
 else {header=Buffer.alloc(10);header[1]=127;header.writeBigUInt64BE(BigInt(size),2);}
 header[0]=0x80|opcode;return Buffer.concat([header,msg]);
}
function send(s,data){if(!s||s.destroyed||!s.writable)return;try{s.write(frame(JSON.stringify(data)));}catch{}}
function makeWS(socket,head){
 const ctx={socket,buffer:Buffer.alloc(0),room:null,slot:-1,rate:0,rateTime:Date.now()};
 socket.setNoDelay(true);
 socket.on('data',data=>{
  ctx.buffer=Buffer.concat([ctx.buffer,data]);
  if(ctx.buffer.length>65536){socket.destroy();return;}
  while(ctx.buffer.length>=2){
   let buf=ctx.buffer,byte=buf[0],opcode=byte&0x0f,fin=(byte&0x80)!==0,masked=(buf[1]&0x80)!==0,len=buf[1]&127,off=2;
   if(!fin||!masked){socket.destroy();return;}
   if(len===126){if(buf.length<4)return;len=buf.readUInt16BE(2);off=4;}
   else if(len===127){if(buf.length<10)return;const size=buf.readBigUInt64BE(2);if(size>BigInt(32768)){socket.destroy();return;}len=Number(size);off=10;}
   if(len>32768){socket.destroy();return;}
   if(buf.length<off+4+len)return;
   const key=buf.subarray(off,off+4),payload=Buffer.from(buf.subarray(off+4,off+4+len));
   for(let i=0;i<len;i++)payload[i]^=key[i%4];
   ctx.buffer=buf.subarray(off+4+len);
   if(opcode===8){socket.end(frame(Buffer.alloc(0),8));return;}
   if(opcode===9){socket.write(frame(payload,10));continue;}
   if(opcode===10)continue;
   if(opcode!==1){socket.destroy();return;}
   const now=Date.now();if(now-ctx.rateTime>10000){ctx.rateTime=now;ctx.rate=0;}
   if(++ctx.rate>80){socket.destroy();return;}
   let data;try{data=JSON.parse(payload.toString('utf8'));}catch{send(socket,{type:'error',message:'不正なデータ'});continue;}
   try{dispatch(ctx,data);}catch(e){console.error('game handler',e);send(socket,{type:'error',message:'処理に失敗しました。もう一度操作してください。'});}
  }
 });
 const onClose=()=>{const r=ctx.room;if(r&&r.players[ctx.slot]&&r.players[ctx.slot].socket===socket){r.players[ctx.slot].socket=null;r.updated=Date.now();notify(r);}};
 socket.on('close',onClose);socket.on('error',()=>{});
 if(head?.length)socket.emit('data',head);
}
server.on('upgrade',(req,socket,head)=>{
 const origin=req.headers.origin;
 if(origin){try{if(new URL(origin).host!==req.headers.host){socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');socket.destroy();return;}}catch{socket.destroy();return;}}
 if(req.url!=='/ws'||req.headers.upgrade?.toLowerCase()!=='websocket'||req.headers['sec-websocket-version']!=='13'||!req.headers['sec-websocket-key']){socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');socket.destroy();return;}
 const accept=crypto.createHash('sha1').update(req.headers['sec-websocket-key']+GUID).digest('base64');
 socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
 makeWS(socket,head);
});
function code(){let out;do{out='';for(let i=0;i<6;i++)out+=CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];}while(rooms.has(out));return out;}
function nickname(name){if(typeof name!=='string')return 'プレイヤー';return name.replace(/[\x00-\x1f<>]/g,'').trim().slice(0,16)||'プレイヤー';}
function cleanCode(v){return typeof v==='string'?v.toUpperCase().replace(/\s/g,'').slice(0,6):'';}
function error(ctx,message){send(ctx.socket,{type:'error',message});}
function attach(ctx,room,index){
 if(ctx.room&&ctx.room!==room){error(ctx,'入室済みのルームがあります');return false;}
 ctx.room=room;ctx.slot=index;const p=room.players[index];
 if(p.socket&&p.socket!==ctx.socket){try{p.socket.end(frame(Buffer.alloc(0),8));}catch{}}
 p.socket=ctx.socket;room.updated=Date.now();
 send(ctx.socket,{type:'joined',room:room.code,token:p.token,seat:index});notify(room);return true;
}
function notify(room){
 const ppl=room.players.map(p=>p?{name:p.name,ready:p.ready,connected:!!(p.socket&&!p.socket.destroyed)}:null);
 for(let i=0;i<2;i++){
  const p=room.players[i];if(!p?.socket||p.socket.destroyed)continue;
  send(p.socket,{type:'room',room:room.code,seat:i,players:ppl,game:room.game?E.snapshot(room.game,i):null,rematch:room.rematch});
 }
}
function dispatch(ctx,m){
 if(!m||typeof m!=='object'||Array.isArray(m)||typeof m.type!=='string')return error(ctx,'不正な操作');
 if(m.type==='heartbeat'){if(ctx.room)ctx.room.updated=Date.now();return;}
 if(m.type==='create'){
  if(ctx.room)return error(ctx,'すでにルームにいます');
  if(rooms.size>=500)return error(ctx,'現在、ルーム数が上限です');
  const id=code(),room={code:id,players:[{name:nickname(m.name),token:crypto.randomBytes(24).toString('hex'),socket:null,ready:false,deck:null},null],game:null,updated:Date.now(),rematch:[false,false]};rooms.set(id,room);attach(ctx,room,0);return;
 }
 if(m.type==='join'){
  if(ctx.room)return error(ctx,'すでにルームにいます');
  const room=rooms.get(cleanCode(m.room));if(!room)return error(ctx,'ルームが見つかりません（サーバー再起動でも消えます）');
  if(typeof m.token==='string'){
   const idx=room.players.findIndex(p=>p&&p.token===m.token);if(idx>=0){attach(ctx,room,idx);return;}
  }
  if(room.players[1])return error(ctx,'このルームは満員です');
  room.players[1]={name:nickname(m.name),token:crypto.randomBytes(24).toString('hex'),socket:null,ready:false,deck:null};attach(ctx,room,1);return;
 }
 if(!ctx.room)return error(ctx,'まずルームへ入ってください');
 const room=ctx.room,i=ctx.slot,p=room.players[i];
 if(!p||p.socket!==ctx.socket)return error(ctx,'認証されていません');
 room.updated=Date.now();
 if(m.type==='ready'){
  if(room.game)return error(ctx,'対戦が始まっています');
  if(m.ready===false){p.ready=false;p.deck=null;notify(room);return;}
  if(!E.validDeck(m.deck))return error(ctx,'デッキは15枚・同名2枚までにしてください');
  p.deck=[...m.deck];p.ready=true;
  if(room.players.every(x=>x?.ready)){
   room.game=E.createGame(room.players[0].deck,room.players[1].deck);
   room.rematch=[false,false];
  }
  notify(room);return;
 }
 if(m.type==='leave'){
  if(room.game){error(ctx,'対戦中は画面を閉じても再接続できます');return;}
  room.players[i]=null;
  if(i===0){for(const other of room.players){if(other?.socket)send(other.socket,{type:'error',message:'ルーム作成者が退出しました'});}rooms.delete(room.code);}
  else notify(room);
  ctx.room=null;ctx.slot=-1;send(ctx.socket,{type:'left'});return;
 }
 if(m.type==='rematch'){
  if(!room.game||room.game.phase!=='over')return error(ctx,'対戦終了後に再戦できます');
  room.rematch[i]=true;
  if(room.rematch.every(Boolean)){
   room.game=null;room.rematch=[false,false];
   for(const other of room.players){other.ready=false;other.deck=null;}
  }
  notify(room);return;
 }
 const g=room.game;if(!g)return error(ctx,'相手の準備を待ってください');
 let ok=false;
 if(m.type==='pick')ok=E.select(g,i,m.choice);
 else if(m.type==='ack')ok=E.ack(g,i);
 else if(m.type==='optional')ok=E.optional(g,i,m.yes);
 else return error(ctx,'対応していない操作です');
 if(!ok)return error(ctx,'今はその操作を実行できません');
 notify(room);
}
setInterval(()=>{
 const now=Date.now();
 for(const [key,room] of rooms){
  if(now-room.updated>3*60*60*1000){for(const p of room.players)if(p?.socket)send(p.socket,{type:'error',message:'ルームの有効期限が終了しました'});rooms.delete(key);}
  else for(const p of room.players){const s=p?.socket;if(s&&!s.destroyed)try{s.write(frame(Buffer.from('ping'),9));}catch{}}
 }
},25000).unref();
server.listen(PORT,'0.0.0.0',()=>console.log(`はじまりの空の町 http://localhost:${server.address().port}`));
module.exports={server,rooms};
