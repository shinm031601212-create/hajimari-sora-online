'use strict';
const crypto = require('node:crypto');
const definitions = require('./public/cards.json');
const byId = new Map(definitions.map(c=>[c.id,c]));
function validDeck(deck){
 if(!Array.isArray(deck)||deck.length!==15)return false;
 const count=new Map();
 for(const id of deck){if(typeof id!=='string'||!byId.has(id))return false;count.set(id,(count.get(id)||0)+1);if(count.get(id)>2)return false;}
 return true;
}
function shuffled(arr){for(let i=arr.length-1;i>0;i--){let j=crypto.randomInt(i+1);[arr[i],arr[j]]=[arr[j],arr[i]];}return arr;}
function makeSide(i,selection){
 const cards=shuffled(selection.map((type,n)=>({uid:`${i}-${n}-${crypto.randomBytes(4).toString('hex')}`,type})));
 return {deck:cards,barriers:cards.splice(0,3),hand:cards.splice(0,2),trash:[],costZone:[],battle:null,fresh:false,chosen:null,defeat:null,refreshed:0};
}
function createGame(deck0,deck1){
 if(!validDeck(deck0)||!validDeck(deck1))throw new Error('デッキの構成が不正です。');
 const game={round:0,phase:'choose',sides:[makeSide(0,deck0),makeSide(1,deck1)],ack:[false,false],last:null,logs:[],winner:null,reason:'',optional:[],optionalWho:null};
 writeLog(game,'ゲーム開始。お互い15枚、バリア3枚、初期手札2枚。');
 beginRound(game);
 return game;
}
function writeLog(g,msg){g.logs.push(`T${g.round}: ${msg}`);if(g.logs.length>75)g.logs.shift();}
function lose(g,s,msg){if(!s.defeat){s.defeat=msg;writeLog(g,`プレイヤー${g.sides.indexOf(s)+1}が敗北：${msg}`);}}
function checkGameOver(g){
 const [a,b]=g.sides.map(s=>s.defeat);
 if(!a&&!b)return false;
 g.winner=a&&b?'tie':a?1:0;
 g.reason=a&&b?`両者敗北（P1：${a}／P2：${b}）`:`プレイヤー${a?1:2}：${a||b}`;
 g.phase='over';g.ack=[false,false];writeLog(g,g.winner==='tie'?'引き分けで終了':`プレイヤー${g.winner+1}の勝利！`);return true;
}
function refresh(g,s,required,context){
 if(s.deck.length)return true;
 if(!s.barriers.length){lose(g,s,'バリア0枚でリフレッシュ');return false;}
 if(!s.trash.length){if(required)lose(g,s,`${context}：デッキとトラッシュにカードがない`);return false;}
 s.deck=shuffled(s.trash.splice(0));s.refreshed++;writeLog(g,`プレイヤー${g.sides.indexOf(s)+1}：${s.deck.length}枚でリフレッシュ`);return true;
}
function take(g,s,to,context){
 if(s.defeat)return null;
 if(!refresh(g,s,true,context))return null;
 if(!s.deck.length)return null;
 const c=s.deck.shift();if(to)s[to].push(c);
 refresh(g,s,false,context);
 return c;
}
function beginRound(g){
 if(g.phase==='over')return;
 g.round++;g.phase='choose';g.ack=[false,false];g.last=null;g.optional=[];g.optionalWho=null;
 for(const s of g.sides){s.chosen=null;s.fresh=false;take(g,s,'hand','ドロー');}
 writeLog(g,`第${g.round}ターン：両者ドロー`);
 if(checkGameOver(g))return;
 for(const s of g.sides)if(!s.hand.length&&!s.battle)lose(g,s,'バトルに出せるカードがない');
 checkGameOver(g);
}
function select(g,i,choice){
 if(g.phase!=='choose'||g.sides[i].chosen)return false;
 const s=g.sides[i];
 if(choice&&choice.kind==='keep'&&s.battle)s.chosen={kind:'keep'};
 else if(choice&&choice.kind==='play'&&s.hand.some(c=>c.uid===choice.uid))s.chosen={kind:'play',uid:choice.uid};
 else return false;
 if(g.sides.every(x=>x.chosen)){
  for(let p=0;p<2;p++){
   let a=g.sides[p],d=a.chosen;
   if(d.kind==='keep'){a.fresh=false;continue;}
   if(a.battle){a.trash.push(a.battle);a.battle=null;writeLog(g,`プレイヤー${p+1}がカードを交換`);}
   let ix=a.hand.findIndex(c=>c.uid===d.uid);
   if(ix<0)throw new Error('不正な選択');
   a.battle=a.hand.splice(ix,1)[0];a.fresh=true;
  }
  g.phase='open';g.ack=[false,false];writeLog(g,'両者のカード選択が確定');
 }
 return true;
}
function computeBattle(c0,c1,f0,f1){
 const ts=[byId.get(c0.type),byId.get(c1.type)];const baseline=ts.map(c=>c.soul);const delta=[0,0];const events=[];const negate=[false,false];
 for(let i=0;i<2;i++)if(ts[i].id==='skull'&&baseline[i]>baseline[1-i]){negate[1-i]=true;events.push(`${ts[i].name}：相手の能力を無効`);}
 for(let i=0;i<2;i++){
  if(negate[i])continue;
  const t=ts[i],j=1-i,lose=baseline[i]<baseline[j],tie=baseline[i]===baseline[j],fresh=i===0?f0:f1;let n=0,target=i;
  switch(t.id){
   case 'cloud':case 'sun':if(lose)n=2;break;
   case 'star':if(tie)n=1;break;
   case 'storm':if(baseline[j]>=5){target=j;n=-1;}break;
   case 'moon':if(baseline[j]>=6)n=2;break;
   case 'flower':if(fresh)n=1;break;
   case 'pillar':if(!fresh)n=1;break;
   case 'tree':if(ts[j].cost>=3)n=2;break;
   case 'sword':if(fresh)n=2;break;
   case 'leaf':if(!fresh){target=j;n=-1;}break;
   case 'kama':if(lose){target=j;n=-1;}break;
   case 'three':if(tie)n=2;break;
   case 'horn':if(baseline[j]<=4)n=2;break;
   case 'wind':if(fresh){target=j;n=-1;}break;
  }
  if(n){delta[target]+=n;events.push(`${t.name}【${t.ability}】：${target===i?'自分':'相手'}の魂値${n>0?'+':''}${n}`);}
 }
 const final=baseline.map((v,i)=>v+delta[i]);const winner=final[0]===final[1]?'tie':final[0]>final[1]?0:1;
 return {baseline,final,winner,events,negate};
}
function resolveBattle(g){
 if(g.phase!=='battle')return false;
 const [a,b]=g.sides;const r=computeBattle(a.battle,b.battle,a.fresh,b.fresh);g.last=r;
 writeLog(g,`魂値 ${r.baseline.join('対')} → ${r.final.join('対')}：${r.winner==='tie'?'引き分け':`プレイヤー${r.winner+1}が勝利`}`);
 for(const e of r.events)writeLog(g,e);
 if(r.winner!=='tie'){
  const side=g.sides[1-r.winner];if(side.barriers.length){side.trash.push(side.barriers.pop());writeLog(g,`プレイヤー${2-r.winner}のバリアが1枚減少`);}
  else lose(g,side,'バリア0枚でバトル敗北');
 }
 if(checkGameOver(g))return true;
 g.optional=[];
 for(let i=0;i<2;i++){
  const t=byId.get(g.sides[i].battle.type);
  if(!r.negate[i]&&((t.id==='bird'&&r.winner===1-i)||(t.id==='book'&&r.winner===i)))g.optional.push(i);
 }
 g.phase='result';g.ack=[false,false];return true;
}
function advanceOptional(g){
 g.optionalWho=g.optional.length?g.optional.shift():null;
 g.phase=g.optionalWho===null?'payment':'optional';g.ack=[false,false];
}
function optional(g,i,yes){
 if(g.phase!=='optional'||g.optionalWho!==i||typeof yes!=='boolean')return false;
 if(yes){const c=take(g,g.sides[i],'hand','特殊能力のドロー');writeLog(g,`プレイヤー${i+1}：${c?'特殊能力で1枚ドロー':'ドロー不可'}`);}
 else writeLog(g,`プレイヤー${i+1}：任意ドローを使用しなかった`);
 if(checkGameOver(g))return true;
 advanceOptional(g);return true;
}
function makePayment(g){
 g.phase='cost';g.ack=[false,false];
 // 両者とも支払いを行い、同時敗北の可能性を残す
 for(let i=0;i<2;i++){
  const s=g.sides[i],n=byId.get(s.battle.type).cost;
  for(let k=0;k<n;k++){if(!take(g,s,'costZone','コスト支払い'))break;}
  writeLog(g,`プレイヤー${i+1}：コスト${n}枚を支払い`);
 }
 checkGameOver(g);
}
function completeCost(g){
 for(const s of g.sides){s.trash.push(...s.costZone);s.costZone=[];}
 if(g.last.winner==='tie'){
  for(const s of g.sides){s.trash.push(s.battle);s.battle=null;}
  writeLog(g,'引き分け：両者のバトルカードをトラッシュへ');
 }else{
  const i=1-g.last.winner,s=g.sides[i];s.trash.push(s.battle);s.battle=null;
  writeLog(g,`プレイヤー${i+1}の敗北カードをトラッシュへ`);
 }
 for(const s of g.sides)refresh(g,s,false,'コスト終了');
 if(checkGameOver(g))return;
 g.phase='end';g.ack=[false,false];
}
function ack(g,i){
 const p=g.phase;if(!['open','battle','result','payment','cost','end'].includes(p))return false;
 g.ack[i]=true;if(!g.ack.every(Boolean))return true;
 g.ack=[false,false];
 if(p==='open')g.phase='battle';
 else if(p==='battle')resolveBattle(g);
 else if(p==='result')advanceOptional(g);
 else if(p==='payment')makePayment(g);
 else if(p==='cost')completeCost(g);
 else if(p==='end')beginRound(g);
 return true;
}
function snapshot(g,i){
 const me=g.sides[i],op=g.sides[1-i];
 const card=c=>c?{type:c.type,uid:c.uid}:null;
 const common=(s,isMine)=>({deck:s.deck.length,barriers:s.barriers.length,handCount:s.hand.length,trash:s.trash.length,refreshed:s.refreshed,selected:!!s.chosen,battle:g.phase==='choose'||g.phase==='open'?(s.fresh?null:card(s.battle)):card(s.battle),back:!!s.battle&&s.fresh&&(g.phase==='choose'||g.phase==='open'),fresh:s.fresh,costZone:g.phase==='cost'?s.costZone.map(c=>c.type):[],defeat:s.defeat});
 return {round:g.round,phase:g.phase,me:common(me,true),op:common(op,false),hand:me.hand.map(card),ack:g.ack[i],opAck:g.ack[1-i],selection:me.chosen,optionalMine:g.optionalWho===i,optionalPending:g.optionalWho===null?null:g.optionalWho,last:g.last,winner:g.winner,reason:g.reason,logs:g.logs.slice(-18)};
}
module.exports={definitions,validDeck,createGame,select,ack,optional,snapshot,computeBattle};
