'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {once}=require('node:events');
const crypto=require('node:crypto');
process.env.PORT='0';
const {server,rooms}=require('../server');
const preset=['cloud','sun','star','rock','storm','bird','moon','flower','pillar','tree','sword','skull','book','leaf','wind'];
class Client{
 constructor(ws){this.ws=ws;this.messages=[];ws.addEventListener('message',e=>{this.messages.push(JSON.parse(e.data));});}
 send(o){this.ws.send(JSON.stringify(o));}
 async wait(fn,ms=4000){let t=Date.now();while(Date.now()-t<ms){let idx=this.messages.findIndex(fn);if(idx>=0)return this.messages.splice(idx,1)[0];await new Promise(r=>setTimeout(r,8));}throw new Error('timeout: '+JSON.stringify(this.messages.slice(-3)));}
 async state(fn=()=>true){return this.wait(m=>m.type==='room'&&fn(m));}
 async close(){this.ws.close();}
}
async function connect(port){let ws=new WebSocket(`ws://127.0.0.1:${port}/ws`);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true});});return new Client(ws);}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
test('websocket two players hidden information, phase sync, rematch and reconnect',async()=>{
 if(!server.listening)await once(server,'listening');
 const port=server.address().port;
 const r=await fetch(`http://127.0.0.1:${port}/health`);assert.equal(r.status,200);
 const a=await connect(port),b=await connect(port);
 a.send({type:'create',name:'P1'});const first=await a.wait(m=>m.type==='joined');assert.equal(first.seat,0);
 const name=first.room;assert.equal(name.length,6);
 b.send({type:'join',room:name,name:'P2'});const second=await b.wait(m=>m.type==='joined');assert.equal(second.seat,1);
 a.send({type:'ready',deck:preset});b.send({type:'ready',deck:preset});
 const aChoose=await a.state(m=>m.game?.phase==='choose'),bChoose=await b.state(m=>m.game?.phase==='choose');
 assert.equal(aChoose.game.hand.length,3);assert.equal(bChoose.game.hand.length,3);
 assert.equal(aChoose.game.op.handCount,3);assert.equal(Object.hasOwn(aChoose.game.op,'hand'),false);
 const ca=aChoose.game.hand[0],cb=bChoose.game.hand[0];
 a.send({type:'pick',choice:{kind:'play',uid:ca.uid}});
 const aLock=await a.state(m=>m.game?.me.selected===true);assert.equal(aLock.game.phase,'choose');
 const bLock=await b.state(m=>m.game?.op.selected===true);assert.equal(bLock.game.op.battle,null);
 b.send({type:'pick',choice:{kind:'play',uid:cb.uid}});
 const aOpen=await a.state(m=>m.game?.phase==='open'),bOpen=await b.state(m=>m.game?.phase==='open');
 assert.equal(aOpen.game.op.battle,null);assert.equal(aOpen.game.op.back,true);
 assert.equal(bOpen.game.op.battle,null);assert.equal(bOpen.game.op.back,true);
 // Each player acknowledges open and only then both cards appear
 a.send({type:'ack'});await a.state(m=>m.game?.phase==='open'&&m.game.ack===true);
 b.send({type:'ack'});await a.state(m=>m.game?.phase==='battle');await b.state(m=>m.game?.phase==='battle');
 a.send({type:'ack'});b.send({type:'ack'});
 const ar=await a.state(m=>m.game?.phase==='result'||m.game?.phase==='over');
 const br=await b.state(m=>m.game?.phase==='result'||m.game?.phase==='over');
 assert.ok(ar.game.last);assert.deepEqual(ar.game.last.final,br.game.last.final);
 if(ar.game.phase!=='over'){
  a.send({type:'ack'});b.send({type:'ack'});
  let p=await a.state(m=>m.game?.phase==='payment'||m.game?.phase==='optional');
  if(p.game.phase==='optional'){
   let ix=p.game.optionalPending;(ix===0?a:b).send({type:'optional',yes:false});
   await a.state(m=>m.game?.phase==='payment');
  }
  a.send({type:'ack'});b.send({type:'ack'});
  const x=await a.state(m=>m.game?.phase==='cost'||m.game?.phase==='over');
  if(x.game.phase==='cost'){a.send({type:'ack'});b.send({type:'ack'});await a.state(m=>m.game?.phase==='end'||m.game?.phase==='over');}
 }
 // Ignore join without valid token (full room)
 const c=await connect(port);c.send({type:'join',room:name,name:'intruder'});await c.wait(m=>m.type==='error'&&m.message.includes('満員'));
 await a.close();
 const reconnect=await connect(port);
 reconnect.send({type:'join',room:name,token:first.token});
 const resume=await reconnect.wait(m=>m.type==='joined');assert.equal(resume.seat,0);
 const restored=await reconnect.state(m=>!!m.game);assert.equal(restored.seat,0);assert.equal(restored.game.me.handCount,restored.game.hand.length);
 await reconnect.close();await b.close();await c.close();
});
test.after(async()=>{await new Promise(r=>server.close(r));});
