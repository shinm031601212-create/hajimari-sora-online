'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../engine');
const ids=E.definitions.map(c=>c.id);
const base=['cloud','sun','star','rock','storm','bird','moon','flower','pillar','tree','sword','skull','book','leaf','wind'];
function inv(g){for(const s of g.sides){let n=s.deck.length+s.barriers.length+s.hand.length+s.trash.length+s.costZone.length+(s.battle?1:0);assert.equal(n,15,`wrong card count ${n} round ${g.round} phase ${g.phase}`);}}
test('deck validation',()=>{
 assert.equal(E.validDeck(base),true);
 assert.equal(E.validDeck(['cloud','cloud','cloud',...base.slice(3)]),false);
 assert.equal(E.validDeck([...base,'sun']),false);
 assert.equal(E.validDeck(Array(15).fill('sun')),false);
});
test('ability timing',()=>{
 const c=id=>({type:id});
 assert.deepEqual(E.computeBattle(c('sword'),c('rock'),true,true).final,[6,4]);
 assert.deepEqual(E.computeBattle(c('sword'),c('rock'),false,true).final,[4,4]);
 assert.deepEqual(E.computeBattle(c('pillar'),c('rock'),false,true).final,[6,4]);
 assert.deepEqual(E.computeBattle(c('sun'),c('skull'),true,true).final,[4,5]); // skull initially wins, negate reversal
});
test('2,000 full matches preserve cards and terminate',()=>{
 const scores={games:0,draw:0,win0:0,win1:0,min:999,max:0};
 for(let match=0;match<2000;match++){
  const g=E.createGame(base,base);let n=0;inv(g);
  while(g.phase!=='over'&&n++<1000){
   switch(g.phase){
    case'choose':for(let i=0;i<2;i++){let s=g.sides[i];let choice=s.battle&&Math.random()<.4?{kind:'keep'}:{kind:'play',uid:s.hand[Math.floor(Math.random()*s.hand.length)].uid};assert.equal(E.select(g,i,choice),true);}break;
    case'open':case'battle':case'result':case'payment':case'cost':case'end':E.ack(g,0);E.ack(g,1);break;
    case'optional':E.optional(g,g.optionalWho,Math.random()>.4);break;
    default:assert.fail('unknown '+g.phase);
   }
   inv(g);
  }
  assert.equal(g.phase,'over',`not terminated match${match}`);
  scores.games++;scores.min=Math.min(scores.min,g.round);scores.max=Math.max(scores.max,g.round);
  if(g.winner==='tie')scores.draw++;else scores['win'+g.winner]++;
 }
 console.log('matches',JSON.stringify(scores));
});
